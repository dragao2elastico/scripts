function onStartCountdown()
    if buildTarget == 'browser' then
            makeLuaSprite('pirate', 'pirate', 0, 0)
            addLuaSprite('pirate')
            setObjectCamera('pirate', 'hud')
			setProperty('scoreTxt.visible', false)
            setProperty('healthBar.visible', false)
            setProperty('healthBarBG.visible', false)
            setProperty('iconP1.visible', false)
            setProperty('iconP2.visible', false)
            
			setProperty('dad.visible',false)
            setProperty('boyfriend.visible', false)
            setProperty('gf.visible', false)
            playSound("piracy")
			return Function_Stop;
	        end
		end